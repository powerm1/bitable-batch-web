import { useState, useRef } from "react";
import { ConfigPanel } from "@/components/ConfigPanel";
import { TaskInput } from "@/components/TaskInput";
import { Console } from "@/components/Console";
import { StatsCards } from "@/components/StatsCards";
import { ResultsTable } from "@/components/ResultsTable";
import { BitableClient } from "@/lib/bitable";
import type { ProcessResult } from "@/lib/bitable";
import { toast } from "sonner";
import { Activity } from "lucide-react";

// Default config from original script
const DEFAULT_CONFIG = {
  appId: "cli_a73bda7327399013",
  appSecret: "IxStGQLRexU8XAKuu2uyAfmWQfHPVXlb",
  proxyUrl: "/api/proxy/", // Optimized for Vercel deployment
  concurrency: 5,
  salesThreshold: "20",
  locationOptions: "CN, CN(HK)"
};

export default function Home() {
  const [config, setConfig] = useState(DEFAULT_CONFIG);
  const [isProcessing, setIsProcessing] = useState(false);
  const [logs, setLogs] = useState<{ time: string; type: 'info' | 'error' | 'success'; message: string }[]>([]);
  const [results, setResults] = useState<any[]>([]); // ResultItem[]
  
  const stopRef = useRef(false);

  const addLog = (message: string, type: 'info' | 'error' | 'success' = 'info') => {
    const time = new Date().toLocaleTimeString('en-US', { hour12: false });
    setLogs(prev => [...prev, { time, type, message }]);
  };

  const handleConfigChange = (key: string, value: any) => {
    setConfig(prev => ({ ...prev, [key]: value }));
  };

  const handleStart = async (links: string[]) => {
    if (!config.appId || !config.appSecret) {
      toast.error("请配置 App ID 和 Secret");
      return;
    }

    setIsProcessing(true);
    stopRef.current = false;
    setLogs([]);
    setResults(links.map((url, i) => ({ 
      index: i, 
      url, 
      status: 'pending' 
    })));

    addLog(`初始化完成：${links.length} 个任务已进入队列`, 'info');
    addLog(`配置生效：并发数=${config.concurrency}，代理=${config.proxyUrl || '直连'}`, 'info');
    addLog(`筛选规则：月销量>${config.salesThreshold}，所属地=[${config.locationOptions}]`, 'info');

    const client = new BitableClient({
      appId: config.appId,
      appSecret: config.appSecret,
      proxyUrl: config.proxyUrl,
      salesThreshold: config.salesThreshold,
      locationOptions: config.locationOptions.split(/[,，]/).map(s => s.trim()).filter(Boolean)
    });

    // Test Auth
    try {
      addLog("正在进行身份验证...", 'info');
      await client.getToken();
      addLog("身份验证成功", 'success');
    } catch (e: any) {
      addLog(`身份验证失败：${e.message}`, 'error');
      toast.error("身份验证失败。请检查凭证或 CORS 代理设置。");
      setIsProcessing(false);
      return;
    }

    // Batch Processing
    let processedCount = 0;
    for (let i = 0; i < links.length; i += config.concurrency) {
      if (stopRef.current) {
        addLog("用户停止了进程", 'error');
        break;
      }

      const batch = links.slice(i, i + config.concurrency);
      addLog(`正在处理第 ${i} - ${i + batch.length - 1} 条...`, 'info');

      // Update status to processing
      setResults(prev => prev.map((r, idx) => 
        (idx >= i && idx < i + batch.length) ? { ...r, status: 'processing' } : r
      ));

      // Execute batch
      const promises = batch.map(url => client.processOne(url));
      const batchResults = await Promise.all(promises);

      // Update results
      // We need to map back to original indices
      // batchResults order matches batch order
      setResults(prev => {
        const next = [...prev];
        batchResults.forEach((res, batchIdx) => {
          const globalIdx = i + batchIdx;
          if (res.status === 'ok') {
            next[globalIdx] = {
              ...next[globalIdx],
              status: 'success',
              copy_url: res.copy_url,
              copy2_url: res.copy2_url
            };
            addLog(`[${globalIdx}] 成功：视图已创建`, 'success');
          } else {
            next[globalIdx] = {
              ...next[globalIdx],
              status: 'error',
              error: res.message
            };
            addLog(`[${globalIdx}] 失败：${res.message}`, 'error');
          }
        });
        return next;
      });

      processedCount += batch.length;
      
      // Delay to avoid rate limit (1s)
      if (i + config.concurrency < links.length) {
        await new Promise(r => setTimeout(r, 1000));
      }
    }

    setIsProcessing(false);
    addLog(`执行完毕：已处理 ${processedCount}/${links.length}`, 'success');
    toast.success("批处理任务已完成");
  };

  const stats = {
    total: results.length,
    processed: results.filter(r => r.status !== 'pending' && r.status !== 'processing').length,
    success: results.filter(r => r.status === 'success').length,
    failed: results.filter(r => r.status === 'error').length
  };

  return (
    <div className="flex h-screen bg-slate-950 text-slate-200 overflow-hidden font-sans">
      {/* Sidebar */}
      <div className="w-80 shrink-0">
        <ConfigPanel 
          {...config} 
          onConfigChange={handleConfigChange} 
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-14 border-b border-slate-800 bg-slate-950 flex items-center px-6 gap-2">
          <Activity className="w-5 h-5 text-emerald-500" />
          <h1 className="font-bold text-lg tracking-tight">Bitable 批处理助手 <span className="text-xs font-mono text-slate-500 ml-2">v1.0.0</span></h1>
        </header>

        <main className="flex-1 p-6 overflow-hidden flex flex-col gap-6">
          {/* Top Section: Input & Stats */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 shrink-0">
            <div className="lg:col-span-1">
              <TaskInput onStart={handleStart} isProcessing={isProcessing} />
            </div>
            <div className="lg:col-span-2">
              <StatsCards {...stats} />
              <div className="mt-4 h-[140px]">
                <Console logs={logs} />
              </div>
            </div>
          </div>

          {/* Bottom Section: Results Table */}
          <div className="flex-1 min-h-0">
            <ResultsTable results={results} />
          </div>
        </main>
      </div>
    </div>
  );
}
