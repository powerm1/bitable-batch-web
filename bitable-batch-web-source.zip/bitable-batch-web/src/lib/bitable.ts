import axios from "axios";
import type { AxiosInstance } from "axios";

export interface BitableConfig {
  appId: string;
  appSecret: string;
  proxyUrl?: string;
  salesThreshold?: string;
  locationOptions?: string[];
}

export interface ProcessResult {
  status: "ok" | "error";
  message?: string;
  url: string;
  copy_url?: string;
  copy2_url?: string;
  location_ids?: string[];
}

// Constants from original script
const FIELD_LOCATION_NAME = "卖家所属地";
const FIELD_SALES_NAME = "月销量";
const FIELD_SHIPPING_NAME = "配送方式";
const FIELD_SELLINGPOINT_NAME = "产品卖点";
const DEFAULT_SALES_THRESHOLD = "20";
const DEFAULT_LOCATIONS = ["CN", "CN(HK)"];
const SHIP_EQ = "FBA";
const COPY_NAME = "copy";
const COPY2_NAME = "copy2";
const BASE_URL = "https://open.feishu.cn/open-apis";

export class BitableClient {
  private config: BitableConfig;
  private token: string | null = null;
  private axios: AxiosInstance;

  constructor(config: BitableConfig) {
    this.config = config;
    this.axios = axios.create({
      timeout: 10000,
    });
  }

  private getUrl(endpoint: string): string {
    const target = `${BASE_URL}${endpoint}`;
    if (this.config.proxyUrl) {
      // Ensure proxy URL ends with slash if needed, or just concat
      // Common proxies like cors-anywhere expect the target URL appended
      return `${this.config.proxyUrl}${target}`;
    }
    return target;
  }

  // Parse URL to get tokens
  private extract(docUrl: string) {
    try {
      const u = new URL(docUrl);
      const pathParts = u.pathname.split("/").filter(Boolean);
      // Expected path: /base/{app_token}
      // Or /base/{app_token}/...
      // The original script takes the last part of path stripped of slashes. 
      // Feishu URL: https://feishu.cn/base/Basexxxxx?table=tblxxx&view=vewxxx
      
      // Find 'base' segment index
      const baseIndex = pathParts.indexOf("base");
      if (baseIndex === -1 || baseIndex + 1 >= pathParts.length) {
        throw new Error("Invalid Bitable URL format");
      }
      const appToken = pathParts[baseIndex + 1];
      
      const params = u.searchParams;
      const tableId = params.get("table");
      const viewId = params.get("view");

      if (!tableId || !viewId) {
        throw new Error("URL must contain table and view parameters");
      }

      return { appToken, tableId, srcViewId: viewId, origin: u.origin, pathname: u.pathname };
    } catch (e) {
      throw new Error(`Failed to parse URL: ${docUrl}`);
    }
  }

  async getToken(): Promise<string> {
    if (this.token) return this.token;

    try {
      const res = await this.axios.post(this.getUrl("/auth/v3/tenant_access_token/internal"), {
        app_id: this.config.appId,
        app_secret: this.config.appSecret,
      });

      if (res.data.code !== 0) {
        throw new Error(`Auth failed: ${res.data.msg}`);
      }
      this.token = res.data.tenant_access_token;
      return this.token!;
    } catch (e: any) {
      console.error("Get token error", e);
      throw new Error(e.response?.data?.msg || e.message || "Failed to get token");
    }
  }

  private async req(method: "GET" | "POST" | "PUT" | "PATCH", endpoint: string, data?: any, retries = 3): Promise<any> {
    const token = await this.getToken();
    const url = this.getUrl(endpoint);
    const headers = {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json; charset=utf-8",
    };

    let lastError;
    for (let i = 0; i < retries; i++) {
      try {
        const res = await this.axios.request({ method, url, headers, data });
        // Feishu API usually returns 200 even on error, check code
        if (res.data.code && res.data.code !== 0) {
           // Allow 400-like logic errors to be thrown to catch block
           throw new Error(`API Error ${res.data.code}: ${res.data.msg}`);
        }
        return res.data;
      } catch (e: any) {
        lastError = e;
        // Wait 1s before retry
        await new Promise((r) => setTimeout(r, 1000));
      }
    }
    throw lastError;
  }

  async processOne(url: string): Promise<ProcessResult> {
    try {
      const { appToken, tableId, srcViewId, origin, pathname } = this.extract(url);
      
      // 1. Get Source View
      const srcViewRes = await this.req("GET", `/bitable/v1/apps/${appToken}/tables/${tableId}/views/${srcViewId}`);
      const srcView = srcViewRes.data.view;
      const srcViewType = srcView.view_type;

      // 2. Create/Find Copy View
      const viewsRes = await this.req("GET", `/bitable/v1/apps/${appToken}/tables/${tableId}/views`);
      const views = viewsRes.data.items || [];
      
      let copyId = views.find((v: any) => v.view_name === COPY_NAME || v.name === COPY_NAME)?.view_id;
      
      if (!copyId) {
        const createRes = await this.req("POST", `/bitable/v1/apps/${appToken}/tables/${tableId}/views`, {
          view_name: COPY_NAME,
          view_type: srcViewType
        });
        copyId = createRes.data.view.view_id;
      }

      // 3. Sync Property to Copy
      if (srcView.property) {
        await this.req("PATCH", `/bitable/v1/apps/${appToken}/tables/${tableId}/views/${copyId}`, {
          property: srcView.property
        });
      }

      // 4. Get Fields
      const fieldsRes = await this.req("GET", `/bitable/v1/apps/${appToken}/tables/${tableId}/fields`);
      const fields = fieldsRes.data.items || [];
      const nameToField = Object.fromEntries(fields.map((f: any) => [f.field_name, f]));

      const sales = nameToField[FIELD_SALES_NAME];
      const loc = nameToField[FIELD_LOCATION_NAME];
      const ship = nameToField[FIELD_SHIPPING_NAME];
      const sp = nameToField[FIELD_SELLINGPOINT_NAME];

      if (!sales || !loc || !ship || !sp) {
        return { status: "error", message: "Missing required fields", url };
      }

      // 5. Update Sales Field (Number, Integer)
      // Note: This modifies the field definition globally for the table!
      try {
        await this.req("PUT", `/bitable/v1/apps/${appToken}/tables/${tableId}/fields/${sales.field_id}`, {
          field_name: FIELD_SALES_NAME,
          type: 2, // Number
          ui_type: "Number",
          property: { formatter: "0" } // Integer
        });
      } catch (e) {
        // Ignore update failure (might already be correct or permission issue)
        console.warn("Update field failed, continuing", e);
      }

      // 6. Build Filter Conditions
      // Location IDs
      const locOpts = loc.property?.options || [];
      const locIds: string[] = [];
      const targetLocations = this.config.locationOptions && this.config.locationOptions.length > 0 
        ? this.config.locationOptions 
        : DEFAULT_LOCATIONS;
      
      targetLocations.forEach(nm => {
        const opt = locOpts.find((o: any) => o.name === nm);
        if (opt) locIds.push(opt.id);
      });

      // Shipping ID
      const shipOpts = ship.property?.options || [];
      const shipOpt = shipOpts.find((o: any) => o.name === SHIP_EQ);
      const shipVal = shipOpt ? [shipOpt.id] : [SHIP_EQ]; // Fallback to text if opt not found (though unlikely for SingleSelect)

      // Construct Conditions
      // Logic: if no locIds found, use dummy ID to force empty result
      const locValue = locIds.length > 0 ? locIds : ["opt__NO_CN__"];
      
      const conditions = [
        {
          field_id: loc.field_id,
          operator: "contains",
          value: JSON.stringify(locValue)
        },
        {
          field_id: sales.field_id,
          operator: "isGreater",
          value: JSON.stringify([this.config.salesThreshold || DEFAULT_SALES_THRESHOLD])
        },
        {
          field_id: ship.field_id,
          operator: "is",
          value: JSON.stringify(shipVal)
        },
        {
          field_id: sp.field_id,
          operator: "isNotEmpty",
          value: "[]" // isNotEmpty value is ignored but required by type sometimes? API says value optional for some ops
        }
      ];

      // Apply Filter to Copy View
      await this.req("PATCH", `/bitable/v1/apps/${appToken}/tables/${tableId}/views/${copyId}`, {
        property: {
          filter_info: {
            conjunction: "and",
            conditions: conditions
          }
        }
      });

      // 7. Create/Sync Copy2
      let copy2Id = views.find((v: any) => v.view_name === COPY2_NAME || v.name === COPY2_NAME)?.view_id;
      if (!copy2Id) {
        const c2Res = await this.req("POST", `/bitable/v1/apps/${appToken}/tables/${tableId}/views`, {
          view_name: COPY2_NAME,
          view_type: srcViewType
        });
        copy2Id = c2Res.data.view.view_id;
      }

      // Read updated Copy1 property
      const copy1Info = await this.req("GET", `/bitable/v1/apps/${appToken}/tables/${tableId}/views/${copyId}`);
      if (copy1Info.data.view.property) {
        await this.req("PATCH", `/bitable/v1/apps/${appToken}/tables/${tableId}/views/${copy2Id}`, {
          property: copy1Info.data.view.property
        });
      }

      // 8. Result
      const baseUrl = `${origin}${pathname}?table=${tableId}`;
      return {
        status: "ok",
        url,
        copy_url: `${baseUrl}&view=${copyId}`,
        copy2_url: `${baseUrl}&view=${copy2Id}`,
        location_ids: locIds
      };

    } catch (e: any) {
      return {
        status: "error",
        url,
        message: e.message || String(e)
      };
    }
  }
}
