import { ScrollArea } from "@/components/ui/scroll-area";
import { useEffect, useRef } from "react";

interface ConsoleProps {
  logs: { time: string; type: 'info' | 'error' | 'success'; message: string }[];
}

export function Console({ logs }: ConsoleProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  return (
    <div className="flex flex-col h-full bg-slate-950 border border-slate-800 rounded-lg overflow-hidden font-mono text-xs shadow-inner">
      <div className="bg-slate-900 px-4 py-2 border-b border-slate-800 text-slate-400 font-semibold flex justify-between items-center">
        <span>终端输出</span>
        <div className="flex gap-2">
          <div className="w-3 h-3 rounded-full bg-slate-700" />
          <div className="w-3 h-3 rounded-full bg-slate-700" />
          <div className="w-3 h-3 rounded-full bg-slate-700" />
        </div>
      </div>
      <ScrollArea className="flex-1 p-4">
        <div className="flex flex-col gap-1">
          {logs.map((log, i) => (
            <div key={i} className="flex gap-2">
              <span className="text-slate-500 shrink-0">[{log.time}]</span>
              <span
                className={
                  log.type === "error"
                    ? "text-rose-500"
                    : log.type === "success"
                    ? "text-emerald-500"
                    : "text-slate-300"
                }
              >
                {log.type === "info" && "> "}
                {log.message}
              </span>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>
      </ScrollArea>
    </div>
  );
}
