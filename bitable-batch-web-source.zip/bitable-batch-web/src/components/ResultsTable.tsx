import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Download, ExternalLink } from "lucide-react";
import * as XLSX from "xlsx";

interface ResultItem {
  index: number;
  url: string;
  status: "pending" | "processing" | "success" | "error";
  copy_url?: string;
  copy2_url?: string;
  error?: string;
}

interface ResultsTableProps {
  results: ResultItem[];
}

export function ResultsTable({ results }: ResultsTableProps) {
  
  const handleExport = () => {
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(results.map(r => ({
      Index: r.index,
      Original_URL: r.url,
      状态: r.status,
      Copy_View: r.copy_url || "",
      Copy2_View: r.copy2_url || "",
      Error_Message: r.error || ""
    })));
    XLSX.utils.book_append_sheet(wb, ws, "批处理结果");
    XLSX.writeFile(wb, `bitable_batch_export_${Date.now()}.xlsx`);
  };

  return (
    <div className="h-full flex flex-col bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
      <div className="px-4 py-2 border-b border-slate-800 flex justify-between items-center bg-slate-950">
        <h3 className="font-semibold text-slate-200 text-sm">数据列表</h3>
        <Button variant="outline" size="sm" onClick={handleExport} className="h-7 text-xs border-slate-700 hover:bg-slate-800 hover:text-white">
          <Download className="w-3 h-3 mr-1" /> 导出 XLSX
        </Button>
      </div>
      <ScrollArea className="flex-1">
        <Table>
          <TableHeader className="bg-slate-950/50">
            <TableRow className="border-slate-800 hover:bg-transparent">
              <TableHead className="w-[50px] text-slate-500">#</TableHead>
              <TableHead className="text-slate-500">状态</TableHead>
              <TableHead className="text-slate-500">原始链接</TableHead>
              <TableHead className="text-slate-500">结果视图</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody className="font-mono text-xs">
            {results.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-8 text-slate-600">
                  暂无处理数据
                </TableCell>
              </TableRow>
            ) : (
              results.map((row) => (
                <TableRow key={row.index} className="border-slate-800 hover:bg-slate-800/50">
                  <TableCell className="text-slate-500">{row.index + 1}</TableCell>
                  <TableCell>
                    <Badge 
                      variant="outline" 
                      className={`
                        ${row.status === 'success' ? 'border-emerald-500/50 text-emerald-500 bg-emerald-500/10' : ''}
                        ${row.status === 'error' ? 'border-rose-500/50 text-rose-500 bg-rose-500/10' : ''}
                        ${row.status === 'processing' ? 'border-blue-500/50 text-blue-500 bg-blue-500/10 animate-pulse' : ''}
                        ${row.status === 'pending' ? 'border-slate-700 text-slate-500' : ''}
                      `}
                    >
                      {row.status.toUpperCase()}
                    </Badge>
                  </TableCell>
                  <TableCell className="max-w-[200px] truncate text-slate-400" title={row.url}>
                    {row.url}
                  </TableCell>
                  <TableCell>
                    {row.status === 'success' ? (
                      <div className="flex gap-2">
                        <a href={row.copy_url} target="_blank" className="flex items-center text-blue-400 hover:underline">
                          Copy <ExternalLink className="w-3 h-3 ml-1" />
                        </a>
                        <span className="text-slate-600">|</span>
                        <a href={row.copy2_url} target="_blank" className="flex items-center text-blue-400 hover:underline">
                          Copy2 <ExternalLink className="w-3 h-3 ml-1" />
                        </a>
                      </div>
                    ) : row.status === 'error' ? (
                      <span className="text-rose-400 truncate max-w-[200px] block" title={row.error}>
                        {row.error}
                      </span>
                    ) : (
                      <span className="text-slate-600">-</span>
                    )}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </ScrollArea>
    </div>
  );
}
