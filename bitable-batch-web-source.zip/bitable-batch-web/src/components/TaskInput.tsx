import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { FileSpreadsheet, Link, Upload, Play, Loader2 } from "lucide-react";
import * as XLSX from "xlsx";
import { toast } from "sonner";

interface TaskInputProps {
  onStart: (links: string[]) => void;
  isProcessing: boolean;
}

export function TaskInput({ onStart, isProcessing }: TaskInputProps) {
  const [linksText, setLinksText] = useState("");
  const [fileLinks, setFileLinks] = useState<string[]>([]);
  const [fileName, setFileName] = useState("");

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const json = XLSX.utils.sheet_to_json(sheet, { header: 1 }) as any[][];
      
      // Assume first column contains links
      const links = json
        .map(row => row[0])
        .filter(cell => typeof cell === 'string' && cell.startsWith('http'));
      
      if (links.length === 0) {
        toast.error("第一列未找到有效链接");
        return;
      }

      setFileLinks(links);
      setFileName(file.name);
      toast.success(`从 ${file.name} 加载了 ${links.length} 条链接`);
    } catch (err) {
      toast.error("解析 Excel 文件失败");
      console.error(err);
    }
  };

  const handleStart = (mode: 'text' | 'file') => {
    const targets = mode === 'text' 
      ? linksText.split('\n').map(l => l.trim()).filter(l => l) 
      : fileLinks;
    
    if (targets.length === 0) {
      toast.error("请提供有效的链接");
      return;
    }
    onStart(targets);
  };

  return (
    <div className="space-y-4">
      <Tabs defaultValue="text" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-slate-900">
          <TabsTrigger value="text" className="data-[state=active]:bg-slate-800">
            <Link className="w-4 h-4 mr-2" /> 粘贴链接
          </TabsTrigger>
          <TabsTrigger value="file" className="data-[state=active]:bg-slate-800">
            <FileSpreadsheet className="w-4 h-4 mr-2" /> 导入 Excel
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="text" className="space-y-4 mt-4">
          <Textarea
            placeholder="在此粘贴 Bitable 链接（每行一个）..."
            className="min-h-[120px] bg-slate-950 border-slate-800 font-mono text-xs resize-none focus-visible:ring-emerald-500"
            value={linksText}
            onChange={(e) => setLinksText(e.target.value)}
          />
          <Button 
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white" 
            onClick={() => handleStart('text')}
            disabled={isProcessing || !linksText.trim()}
          >
            {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Play className="mr-2 h-4 w-4" />}
            执行批处理
          </Button>
        </TabsContent>
        
        <TabsContent value="file" className="space-y-4 mt-4">
          <div className="flex flex-col items-center justify-center border-2 border-dashed border-slate-800 rounded-lg p-8 hover:border-slate-600 transition-colors bg-slate-950/50">
            <Upload className="w-8 h-8 text-slate-500 mb-2" />
            <p className="text-sm text-slate-400 mb-4">
              {fileName ? <span className="text-emerald-500 font-mono">{fileName}</span> : "拖拽 Excel 文件或点击浏览"}
            </p>
            <Input 
              type="file" 
              accept=".xlsx,.xls,.csv" 
              className="hidden" 
              id="file-upload"
              onChange={handleFileUpload}
            />
            <Button variant="secondary" onClick={() => document.getElementById('file-upload')?.click()}>
              选择文件
            </Button>
            {fileLinks.length > 0 && (
              <p className="text-xs text-slate-500 mt-2 font-mono">
                {fileLinks.length} 条链接已加载
              </p>
            )}
          </div>
          <Button 
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
            onClick={() => handleStart('file')}
            disabled={isProcessing || fileLinks.length === 0}
          >
            {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Play className="mr-2 h-4 w-4" />}
            执行批处理
          </Button>
        </TabsContent>
      </Tabs>
    </div>
  );
}
