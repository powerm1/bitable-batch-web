import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Settings, Shield, Globe, Filter } from "lucide-react";

interface ConfigProps {
  appId: string;
  appSecret: string;
  proxyUrl: string;
  concurrency: number;
  salesThreshold: string;
  locationOptions: string;
  onConfigChange: (key: string, value: any) => void;
}

export function ConfigPanel({ 
  appId, 
  appSecret, 
  proxyUrl, 
  concurrency, 
  salesThreshold, 
  locationOptions, 
  onConfigChange 
}: ConfigProps) {
  return (
    <Card className="h-full border-r border-slate-800 bg-slate-950 rounded-none border-y-0 border-l-0">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-emerald-500">
          <Settings className="w-5 h-5" />
          系统配置
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label className="text-slate-400 flex items-center gap-2">
            <Shield className="w-4 h-4" /> App ID
          </Label>
          <Input 
            type="password"
            value={appId} 
            onChange={(e) => onConfigChange('appId', e.target.value)}
            className="bg-slate-900 border-slate-800 font-mono text-xs" 
            placeholder="cli_..."
          />
        </div>
        
        <div className="space-y-2">
          <Label className="text-slate-400 flex items-center gap-2">
            <Shield className="w-4 h-4" /> App Secret
          </Label>
          <Input 
            type="password"
            value={appSecret} 
            onChange={(e) => onConfigChange('appSecret', e.target.value)}
            className="bg-slate-900 border-slate-800 font-mono text-xs" 
            placeholder="••••••••"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-slate-400 flex items-center gap-2">
            <Globe className="w-4 h-4" /> CORS 代理地址
          </Label>
          <Input 
            value={proxyUrl} 
            onChange={(e) => onConfigChange('proxyUrl', e.target.value)}
            className="bg-slate-900 border-slate-800 font-mono text-xs" 
            placeholder="https://cors-anywhere.herokuapp.com/"
          />
          <p className="text-[10px] text-slate-500">
            默认已设置为 Vercel 代理 (/api/proxy/)。
            <br/>如本地运行，请启动 local_proxy.py 并填入 http://localhost:8080/
          </p>
        </div>

        <div className="space-y-4 pt-4 border-t border-slate-800">
          <div className="text-emerald-500 font-semibold flex items-center gap-2 text-sm">
            <Filter className="w-4 h-4" /> 筛选规则
          </div>
          
          <div className="space-y-2">
            <Label className="text-slate-400 text-xs">月销量阈值 (&gt;)</Label>
            <Input 
              type="number"
              value={salesThreshold} 
              onChange={(e) => onConfigChange('salesThreshold', e.target.value)}
              className="bg-slate-900 border-slate-800 font-mono text-xs" 
              placeholder="20"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-slate-400 text-xs">卖家所属地 (逗号分隔)</Label>
            <Input 
              value={locationOptions} 
              onChange={(e) => onConfigChange('locationOptions', e.target.value)}
              className="bg-slate-900 border-slate-800 font-mono text-xs" 
              placeholder="CN, CN(HK)"
            />
          </div>
        </div>

        <div className="pt-4 border-t border-slate-800">
          <div className="flex justify-between text-sm text-slate-400 mb-2">
            <span>并发数</span>
            <span className="font-mono text-emerald-500">{concurrency}</span>
          </div>
          <input 
            type="range" 
            min="1" 
            max="10" 
            value={concurrency}
            onChange={(e) => onConfigChange('concurrency', parseInt(e.target.value))}
            className="w-full h-2 bg-slate-900 rounded-lg appearance-none cursor-pointer accent-emerald-500"
          />
        </div>
      </CardContent>
    </Card>
  );
}
